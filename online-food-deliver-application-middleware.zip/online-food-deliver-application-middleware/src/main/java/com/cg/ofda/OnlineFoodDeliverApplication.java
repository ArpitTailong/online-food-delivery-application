package com.cg.ofda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineFoodDeliverApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFoodDeliverApplication.class, args);
	}

}
