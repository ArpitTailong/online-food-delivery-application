package com.cg.ofda.exception;

public class BillException extends Exception {

	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Bill*/
	public BillException(String errorMessege) {
		super(errorMessege);
	}
}
	

