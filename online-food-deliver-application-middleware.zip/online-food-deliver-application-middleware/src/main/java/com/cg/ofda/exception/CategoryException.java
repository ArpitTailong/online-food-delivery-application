package com.cg.ofda.exception;

public class CategoryException extends Exception {

	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Category*/
	public CategoryException(String errorMessege) {
		super(errorMessege);
	}
}
	
