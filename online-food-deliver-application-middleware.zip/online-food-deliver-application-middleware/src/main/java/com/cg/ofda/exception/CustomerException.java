package com.cg.ofda.exception;

public class CustomerException extends Exception{
	
	
	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Customer*/
	public CustomerException(String errorMessege) {
		super(errorMessege);
	}
}
	
