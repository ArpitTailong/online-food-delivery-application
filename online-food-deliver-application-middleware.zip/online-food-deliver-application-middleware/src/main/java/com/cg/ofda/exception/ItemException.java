package com.cg.ofda.exception;

public class ItemException extends Exception {

	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Item*/
	public ItemException(String errorMessege) {
		super(errorMessege);
	}
}
	
