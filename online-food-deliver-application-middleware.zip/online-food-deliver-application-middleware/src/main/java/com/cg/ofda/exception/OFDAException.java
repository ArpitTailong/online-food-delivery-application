package com.cg.ofda.exception;

public class OFDAException extends Exception{
	
	
	private static final long serialVersionUID = 1L;
	/* UserDefined OFDA Exception */
	public OFDAException(String errorMessege) {
		super(errorMessege);
	}
	

}
