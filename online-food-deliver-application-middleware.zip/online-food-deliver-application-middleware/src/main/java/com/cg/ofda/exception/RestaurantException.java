package com.cg.ofda.exception;
 
public class RestaurantException extends Exception {

	private static final long serialVersionUID = 1L;
	/* UserDefined Exception for Restaurant*/
	public RestaurantException(String errorMessege) {
		super(errorMessege);
	}
}
	
